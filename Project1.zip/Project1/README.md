## Taylan Unal CMPSC442-AI SP21
## Project 1: Search, Due Sunday 2/21 at 11:59pm




## Notes
- Fringe (in AI Search Context) is the set of all nodes at the end of all visited paths. Also known as fringe, frontier, border
- Use Stack, Queue, PriorityQueue from util.py